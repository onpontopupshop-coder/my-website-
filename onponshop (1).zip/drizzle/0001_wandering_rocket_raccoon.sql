CREATE TABLE `shopState` (
	`id` int NOT NULL DEFAULT 1,
	`payload` longtext NOT NULL,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `shopState_id` PRIMARY KEY(`id`)
);
