import { useEffect, useMemo, useState } from "react";
import {
  ArrowRight,
  BarChart3,
  Check,
  CheckCircle2,
  ChevronRight,
  CircleDollarSign,
  Clock3,
  CreditCard,
  Gamepad2,
  Gem,
  ImagePlus,
  LockKeyhole,
  LogOut,
  Menu,
  MessageCircle,
  Moon,
  Pencil,
  Plus,
  QrCode,
  ReceiptText,
  Save,
  Trash2,
  ShieldCheck,
  ShoppingCart,
  Sparkles,
  Sun,
  Tags,
  Upload,
  UserCircle2,
  UserRoundPen,
  WalletCards,
  X,
  Zap,
} from "lucide-react";
import { useTheme } from "../contexts/ThemeContext";
import { startLogin } from "../const";
import { useAuth } from "../_core/hooks/useAuth";
import { trpc } from "../lib/trpc";

type Category = "All" | "Free Fire" | "PUBG UC" | "Mobile Legends" | "UniPin" | "Level Up Pass";
type PaymentMethod = "eSewa" | "Khalti" | "Mobile banking" | "Wallet";
type OrderStatus = "Processing" | "Completed" | "Rejected";

type Product = {
  id: string;
  category: Exclude<Category, "All">;
  name: string;
  subtitle: string;
  price: number;
  tag?: string;
  fields: string[];
  accent: string;
  art: string;
  warning?: string;
  inStock?: boolean;
};

type User = {
  name: string;
  username: string;
  wallet: number;
};

type Order = {
  id: string;
  product: string;
  category: string;
  price: number;
  status: OrderStatus;
  created: string;
  customer: string;
  playerDetails?: Record<string, string>;
  payment?: PaymentMethod;
  transactionId?: string;
  proof?: string;
  rejectionReason?: string;
  createdAt?: number;
};

type CustomerAccount = { openId: string; username: string; name: string; wallet: number };
type Notification = { id: string; username: string; message: string; created: string; createdAt?: number };
type WalletRequest = {
  id: string;
  username: string;
  amount: number;
  method: Exclude<PaymentMethod, "Wallet">;
  transactionId: string;
  proof: string;
  proofData?: string;
  rejectionReason?: string;
  status: OrderStatus;
  created: string;
  createdAt?: number;
};

const qrCodes: Record<Exclude<PaymentMethod, "Wallet">, string> = {
  "eSewa": "/manus-storage/eSewa_My_QR_9811505419_1790770683088_2026-09-30_18_03_03_edit_200430207527175_65fabc09.jpg",
  "Khalti": "/manus-storage/Screenshot_20260930_180318_com_khalti_MainActivity_edit_200417304078789_18c8bd6b.jpg",
  "Mobile banking": "/manus-storage/Screenshot_20260930_180339_com_f1soft_banksmart_siddhartha_MainActivity_edit_200403454389942_da4da26e.jpg",
};

const products: Product[] = [
  { id: "ff25", category: "Free Fire", name: "25 Diamonds", subtitle: "Fast top-up", price: 35, tag: "Starter", fields: ["Game UID", "Game name"], accent: "red", art: "25" },
  { id: "ff50", category: "Free Fire", name: "50 Diamonds", subtitle: "Quick boost", price: 65, fields: ["Game UID", "Game name"], accent: "crimson", art: "50" },
  { id: "ff115", category: "Free Fire", name: "115 Diamonds", subtitle: "Popular pick", price: 120, tag: "Popular", fields: ["Game UID", "Game name"], accent: "ember", art: "115" },
  { id: "ff240", category: "Free Fire", name: "240 Diamonds", subtitle: "More to spend", price: 220, fields: ["Game UID", "Game name"], accent: "night", art: "240" },
  { id: "ff610", category: "Free Fire", name: "610 Diamonds", subtitle: "Best value", price: 570, tag: "Best value", fields: ["Game UID", "Game name"], accent: "ruby", art: "610" },
  { id: "ff1240", category: "Free Fire", name: "1240 Diamonds", subtitle: "Big bundle", price: 1150, fields: ["Game UID", "Game name"], accent: "flare", art: "1.2K" },
  { id: "ff2530", category: "Free Fire", name: "2530 Diamonds", subtitle: "Power bundle", price: 2350, fields: ["Game UID", "Game name"], accent: "carbon", art: "2.5K" },
  { id: "ffweekly", category: "Free Fire", name: "Weekly Membership", subtitle: "7 days of perks", price: 220, tag: "Membership", fields: ["Game UID", "Game name"], accent: "gold", art: "W" },
  { id: "ffmonthly", category: "Free Fire", name: "Monthly Membership", subtitle: "30 days of perks", price: 1100, tag: "Membership", fields: ["Game UID", "Game name"], accent: "violet", art: "M" },
  { id: "pubg57", category: "PUBG UC", name: "57 + 3 Extra UC", subtitle: "60 UC total", price: 155, fields: ["Player ID", "Game name"], accent: "olive", art: "60" },
  { id: "pubg300", category: "PUBG UC", name: "300 + 25 Extra UC", subtitle: "325 UC total", price: 784, tag: "Popular", fields: ["Player ID", "Game name"], accent: "army", art: "325" },
  { id: "pubg600", category: "PUBG UC", name: "600 + 60 Extra UC", subtitle: "660 UC total", price: 1569, fields: ["Player ID", "Game name"], accent: "sand", art: "660" },
  { id: "pubg1500", category: "PUBG UC", name: "1500 + 300 Extra UC", subtitle: "1800 UC total", price: 3919, fields: ["Player ID", "Game name"], accent: "desert", art: "1.8K" },
  { id: "pubg3000", category: "PUBG UC", name: "3000 + 850 Extra UC", subtitle: "3850 UC total", price: 7839, fields: ["Player ID", "Game name"], accent: "steel", art: "3.8K" },
  { id: "pubg6000", category: "PUBG UC", name: "6000 + 2100 Extra UC", subtitle: "8100 UC total", price: 15682, fields: ["Player ID", "Game name"], accent: "midnight", art: "8.1K" },
  { id: "ml5", category: "Mobile Legends", name: "5 Diamonds", subtitle: "Quick top-up", price: 25, fields: ["Zone ID", "User ID"], accent: "cyan", art: "5" },
  { id: "ml11", category: "Mobile Legends", name: "11 Diamonds", subtitle: "Quick top-up", price: 40, fields: ["Zone ID", "User ID"], accent: "blue", art: "11" },
  { id: "ml14", category: "Mobile Legends", name: "14 Diamonds", subtitle: "Quick top-up", price: 45, fields: ["Zone ID", "User ID"], accent: "indigo", art: "14" },
  { id: "ml22", category: "Mobile Legends", name: "22 Diamonds", subtitle: "Quick top-up", price: 75, fields: ["Zone ID", "User ID"], accent: "deepblue", art: "22" },
  { id: "ml42", category: "Mobile Legends", name: "42 Diamonds", subtitle: "Popular pick", price: 135, tag: "Popular", fields: ["Zone ID", "User ID"], accent: "purple", art: "42" },
  { id: "ml55", category: "Mobile Legends", name: "55 Diamonds", subtitle: "More to spend", price: 145, fields: ["Zone ID", "User ID"], accent: "plum", art: "55" },
  { id: "ml56", category: "Mobile Legends", name: "56 Diamonds", subtitle: "More to spend", price: 150, fields: ["Zone ID", "User ID"], accent: "teal", art: "56" },
  { id: "mlweekly", category: "Mobile Legends", name: "Weekly Pass", subtitle: "Weekly pass", price: 295, tag: "Pass", fields: ["Zone ID", "User ID"], accent: "cyan", art: "W" },
  { id: "ml112", category: "Mobile Legends", name: "112 Diamonds", subtitle: "Value bundle", price: 310, fields: ["Zone ID", "User ID"], accent: "blue", art: "112" },
  { id: "ml223", category: "Mobile Legends", name: "223 Diamonds", subtitle: "Value bundle", price: 580, fields: ["Zone ID", "User ID"], accent: "indigo", art: "223" },
  { id: "mltwilight", category: "Mobile Legends", name: "Twilight Pass", subtitle: "Premium pass", price: 1400, tag: "Pass", fields: ["Zone ID", "User ID"], accent: "purple", art: "TP" },
  { id: "unipin", category: "UniPin", name: "UniPin 2000 Voucher", subtitle: "Code delivered securely", price: 2400, tag: "Voucher", fields: ["Email or WhatsApp"], accent: "orange", art: "UP" },
  { id: "levelpass", category: "Level Up Pass", name: "Level 1 → 30 Package", subtitle: "Unlock your next chapter", price: 750, tag: "One-time", fields: ["Game UID", "Game name"], accent: "magenta", art: "1→30", warning: "Level Up Pass can be purchased only once per ID. If it was already used and you buy again, the money will not be refunded." },
];

const categoryMeta: Record<Category, { label: string; icon: typeof Gamepad2; hint: string }> = {
  All: { label: "All products", icon: Sparkles, hint: "Pick your game" },
  "Free Fire": { label: "Free Fire", icon: Gem, hint: "Diamonds & memberships" },
  "PUBG UC": { label: "PUBG UC", icon: Gamepad2, hint: "UC bundles" },
  "Mobile Legends": { label: "Mobile Legends", icon: Zap, hint: "Diamonds & passes" },
  UniPin: { label: "UniPin", icon: CreditCard, hint: "Voucher codes" },
  "Level Up Pass": { label: "Level Up Pass", icon: ArrowRight, hint: "Level 1 to 30" },
};

function formatRs(value: number) {
  return `Rs ${value.toLocaleString("en-IN")}`;
}
function readStored<T>(key: string, fallback: T): T {
  try { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) as T : fallback; } catch { return fallback; }
}
function readGalleryImage(file: File, onReady: (dataUrl: string) => void) {
  const reader = new FileReader();
  reader.onload = () => { if (typeof reader.result === "string") onReady(reader.result); };
  reader.readAsDataURL(file);
}

function CatalogArt({ product, imageUrl }: { product: Product; imageUrl?: string }) {
  return (
    <div className={`catalog-art art-${product.accent}`} style={imageUrl ? { backgroundImage: `url(${imageUrl})` } : undefined}>
      <div className="art-grid" />
      <span className="art-glow" />
      <div className="art-copy"><small>{product.category}</small><strong>{product.art}</strong><em>{product.category === "Free Fire" ? "DIAMONDS" : product.category === "PUBG UC" ? "UC" : product.category === "Mobile Legends" ? "DIAMONDS" : product.category === "UniPin" ? "VOUCHER" : "PASS"}</em></div>
      <span className="art-corner">ONPON / 01</span>
    </div>
  );
}

function Modal({ title, eyebrow, onClose, children, wide = false }: { title: string; eyebrow?: string; onClose: () => void; children: React.ReactNode; wide?: boolean }) {
  return <div className="modal-backdrop" onMouseDown={e => e.target === e.currentTarget && onClose()}><div className={`modal ${wide ? "modal-wide" : ""}`}><button className="icon-button modal-close" onClick={onClose} aria-label="Close"><X size={18} /></button>{eyebrow && <p className="eyebrow">{eyebrow}</p>}<h2>{title}</h2>{children}</div></div>;
}

export default function Home() {
  const { theme, toggleTheme } = useTheme();
  const auth = useAuth();
  const [activeCategory, setActiveCategory] = useState<Category>("All");
  const [activeProduct, setActiveProduct] = useState<Product | null>(null);
  const [authOpen, setAuthOpen] = useState(false);
  const [walletOpen, setWalletOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [adminOpen, setAdminOpen] = useState(false);
  const [adminAuthed, setAdminAuthed] = useState(false);
  const [adminPassword, setAdminPassword] = useState("");
  const [noticeVisible, setNoticeVisible] = useState(true);
  const [mobileMenu, setMobileMenu] = useState(false);
  const [payment, setPayment] = useState<PaymentMethod>("eSewa");
  const [checkoutFields, setCheckoutFields] = useState<Record<string, string>>({});
  const [transactionId, setTransactionId] = useState("");
  const [proofName, setProofName] = useState("");
  const [proofData, setProofData] = useState("");
  const [walletAmount, setWalletAmount] = useState(500);
  const [notifications, setNotifications] = useState<Notification[]>(() => readStored("onpon-notifications", []));
  const [walletTx, setWalletTx] = useState("");
  const [walletProof, setWalletProof] = useState("");
  const [walletProofData, setWalletProofData] = useState("");
  const [profileTab, setProfileTab] = useState<"profile" | "orders">("profile");
  const [user, setUser] = useState<User | null>(null);
  const [loginName, setLoginName] = useState("");
  const [loginUsername, setLoginUsername] = useState("");
  const [usernameDraft, setUsernameDraft] = useState("");
  const [orderStatus, setOrderStatus] = useState<Record<string, OrderStatus>>(() => readStored("onpon-order-status", {}));
  const [orderHistory, setOrderHistory] = useState<Order[]>(() => readStored("onpon-order-history", []));
  const [customerOrderRange, setCustomerOrderRange] = useState<"1d" | "7d" | "1m" | "1y">("1d");
  const [adminOrderRange, setAdminOrderRange] = useState<"1d" | "7d" | "1m" | "1y">("1d");
  const [walletRequests, setWalletRequests] = useState<WalletRequest[]>(() => readStored("onpon-wallet-requests", []));
  const [priceOverrides, setPriceOverrides] = useState<Record<string, number>>(() => readStored("onpon-price-overrides", {}));
  const [imageOverrides, setImageOverrides] = useState<Record<string, string>>(() => readStored("onpon-image-overrides", {}));
  const [catalogImageOverrides, setCatalogImageOverrides] = useState<Record<string, string>>(() => readStored("onpon-catalog-image-overrides", {}));
  const [stockOverrides, setStockOverrides] = useState<Record<string, boolean>>(() => readStored("onpon-stock-overrides", {}));
  const [customerAccounts, setCustomerAccounts] = useState<Record<string, CustomerAccount>>(() => readStored("onpon-customer-accounts", {}));
  const [customProducts, setCustomProducts] = useState<Product[]>(() => readStored("onpon-custom-products", []));
  const [newProduct, setNewProduct] = useState({ category: "Free Fire" as Exclude<Category, "All">, name: "", subtitle: "", price: 100, fields: "Game UID, Game name" });
  const [newProductImage, setNewProductImage] = useState("");
  const [adminWalletUsername, setAdminWalletUsername] = useState("");
  const [adminWalletAmount, setAdminWalletAmount] = useState(100);
  const [walletAdminNotice, setWalletAdminNotice] = useState("");
  const [orderDetails, setOrderDetails] = useState<Record<string, { playerDetails?: Record<string, string>; customer?: string; payment?: PaymentMethod; transactionId?: string; proof?: string; rejectionReason?: string }>>(() => readStored("onpon-order-details", {}));
  const [shopHydrated, setShopHydrated] = useState(false);
  const shopStateQuery = trpc.shop.state.useQuery(undefined, { retry: false, refetchOnWindowFocus: false });
  const saveShopStateMutation = trpc.shop.saveState.useMutation();
  const [adminTab, setAdminTab] = useState<"overview" | "orders" | "catalog">("overview");
  const [adminStoredPassword, setAdminStoredPassword] = useState(() => { try { return localStorage.getItem("onpon-admin-password") || "Aayush@123"; } catch { return "Aayush@123"; } });
  const [newAdminPassword, setNewAdminPassword] = useState("");
  const [passwordNotice, setPasswordNotice] = useState("");

  useEffect(() => {
    if (auth.user) {
      const oauthUsername = `player_${auth.user.openId.slice(-6)}`;
      const savedAccount = customerAccounts[auth.user.openId];
      let savedWallet = savedAccount?.wallet ?? 0;
      try { savedWallet = savedAccount?.wallet ?? Number(localStorage.getItem(`onpon-wallet-${auth.user.openId}`) || "0"); } catch {}
      const resolvedUsername = savedAccount?.username || oauthUsername;
      setUser(previous => ({ name: auth.user?.name || savedAccount?.name || "Onpon player", username: previous?.username || resolvedUsername, wallet: savedWallet || previous?.wallet || 0 }));
      setUsernameDraft(previous => previous || resolvedUsername);
      setCustomerAccounts(previous => ({ ...previous, [auth.user!.openId]: { openId: auth.user!.openId, username: savedAccount?.username || resolvedUsername, name: auth.user!.name || savedAccount?.name || "Onpon player", wallet: savedWallet || previous[auth.user!.openId]?.wallet || 0 } }));
    } else if (!auth.loading) {
      setUser(null);
    }
  }, [auth.user, auth.loading]);

  useEffect(() => {
    if (user && auth.user?.openId) {
      try { localStorage.setItem(`onpon-wallet-${auth.user.openId}`, String(user.wallet)); } catch {}
      setCustomerAccounts(previous => ({ ...previous, [auth.user!.openId]: { openId: auth.user!.openId, username: user.username, name: user.name, wallet: user.wallet } }));
    }
  }, [user, auth.user?.openId]);
  useEffect(() => {
    if (shopHydrated || !shopStateQuery.data) return;
    const state = shopStateQuery.data as Record<string, unknown>;
    if (state.orderStatus) setOrderStatus(state.orderStatus as Record<string, OrderStatus>);
    if (state.orderHistory) setOrderHistory(state.orderHistory as Order[]);
    if (state.walletRequests) setWalletRequests(state.walletRequests as WalletRequest[]);
    if (state.priceOverrides) setPriceOverrides(state.priceOverrides as Record<string, number>);
    if (state.imageOverrides) setImageOverrides(state.imageOverrides as Record<string, string>);
    if (state.catalogImageOverrides) setCatalogImageOverrides(state.catalogImageOverrides as Record<string, string>);
    if (state.stockOverrides) setStockOverrides(state.stockOverrides as Record<string, boolean>);
    if (state.notifications) setNotifications(state.notifications as Notification[]);
    if (state.customerAccounts) setCustomerAccounts(state.customerAccounts as Record<string, CustomerAccount>);
    if (state.orderDetails) setOrderDetails(state.orderDetails as typeof orderDetails);
    if (state.customProducts) setCustomProducts(state.customProducts as Product[]);
    setShopHydrated(true);
  }, [shopHydrated, shopStateQuery.data]);
  useEffect(() => { try { localStorage.setItem("onpon-order-status", JSON.stringify(orderStatus)); } catch {} }, [orderStatus]);
  useEffect(() => { try { localStorage.setItem("onpon-order-history", JSON.stringify(orderHistory)); } catch {} }, [orderHistory]);
  useEffect(() => { try { localStorage.setItem("onpon-wallet-requests", JSON.stringify(walletRequests)); } catch {} }, [walletRequests]);
  useEffect(() => { try { localStorage.setItem("onpon-price-overrides", JSON.stringify(priceOverrides)); } catch {} }, [priceOverrides]);
  useEffect(() => { try { localStorage.setItem("onpon-image-overrides", JSON.stringify(imageOverrides)); } catch {} }, [imageOverrides]);
  useEffect(() => { try { localStorage.setItem("onpon-catalog-image-overrides", JSON.stringify(catalogImageOverrides)); } catch {} }, [catalogImageOverrides]);
  useEffect(() => { try { localStorage.setItem("onpon-stock-overrides", JSON.stringify(stockOverrides)); } catch {} }, [stockOverrides]);
  useEffect(() => { try { localStorage.setItem("onpon-notifications", JSON.stringify(notifications)); } catch {} }, [notifications]);
  useEffect(() => { try { localStorage.setItem("onpon-customer-accounts", JSON.stringify(customerAccounts)); } catch {} }, [customerAccounts]);
  useEffect(() => { try { localStorage.setItem("onpon-custom-products", JSON.stringify(customProducts)); } catch {} }, [customProducts]);
  useEffect(() => { try { localStorage.setItem("onpon-order-details", JSON.stringify(orderDetails)); } catch {} }, [orderDetails]);
  useEffect(() => {
    if (!shopHydrated || saveShopStateMutation.isPending) return;
    saveShopStateMutation.mutate({ state: { orderStatus, orderHistory, walletRequests, priceOverrides, imageOverrides, catalogImageOverrides, stockOverrides, customerAccounts, orderDetails, customProducts, notifications } });
  }, [shopHydrated, orderStatus, orderHistory, walletRequests, priceOverrides, imageOverrides, catalogImageOverrides, stockOverrides, customerAccounts, orderDetails, customProducts, notifications]);

  const allProducts = useMemo(() => [...products, ...customProducts], [customProducts]);
  const displayedProducts = useMemo(() => activeCategory === "All" ? allProducts : allProducts.filter(product => product.category === activeCategory), [activeCategory, allProducts]);
  const productPrice = (product: Product) => priceOverrides[product.id] ?? product.price;
  const productInStock = (product: Product) => stockOverrides[product.id] ?? product.inStock ?? true;
  const pushNotification = (username: string, message: string) => {
    const id = `NOT-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const createdAt = Date.now();
    setNotifications(previous => [{ id, username, message, created: "Just now", createdAt }, ...previous].slice(0, 100));
    window.setTimeout(() => setNotifications(previous => previous.filter(item => item.id !== id)), 3000);
  };
  const orders: Order[] = useMemo(() => {
    const legacyOrders = Object.entries(orderStatus).map(([id, status]) => {
      const p = allProducts.find(product => product.id === id);
      return p ? { id: `OP-${id.toUpperCase()}`, product: p.name, category: p.category, price: productPrice(p), status, created: "Today, 10:42 AM", createdAt: Date.now(), customer: orderDetails[id]?.customer ?? user?.username ?? "guest_user", ...(orderDetails[id] ?? {}) } : null;
    }).filter(Boolean) as Order[];
    const storedIds = new Set(orderHistory.map(order => order.id));
    return [...orderHistory, ...legacyOrders.filter(order => !storedIds.has(order.id))];
  }, [orderHistory, orderStatus, priceOverrides, orderDetails, allProducts, user]);
  const rangeStart = (range: "1d" | "7d" | "1m" | "1y") => Date.now() - ({ "1d": 86400000, "7d": 604800000, "1m": 2592000000, "1y": 31536000000 }[range]);
  const ordersInRange = (items: Order[], range: "1d" | "7d" | "1m" | "1y") => items.filter(order => !order.createdAt || order.createdAt >= rangeStart(range));
  const customerOrders = ordersInRange(orders.filter(order => order.customer === user?.username), customerOrderRange);
  const customerWalletHistory = walletRequests.filter(request => request.username === user?.username && (!request.createdAt || request.createdAt >= rangeStart(customerOrderRange)));
  const adminOrders = ordersInRange(orders, adminOrderRange);
  const adminWalletRequests = walletRequests.filter(request => !request.createdAt || request.createdAt >= rangeStart(adminOrderRange));

  const openCheckout = (product: Product) => {
    if (!user) { setAuthOpen(true); return; }
    if (!productInStock(product)) { pushNotification(user.username, `${product.name} is currently out of stock.`); return; }
    setActiveProduct(product); setPayment("eSewa"); setCheckoutFields({}); setTransactionId(""); setProofName(""); setProofData("");
  };

  const finishCheckout = () => {
    if (!activeProduct || !user || !productInStock(activeProduct)) return;
    if (payment === "Wallet" && user.wallet < productPrice(activeProduct)) return;
    if (payment !== "Wallet" && (!transactionId || !proofName)) return;
    const createdAt = Date.now();
    const orderId = `OP-${createdAt.toString(36).toUpperCase()}`;
    const newOrder: Order = { id: orderId, product: activeProduct.name, category: activeProduct.category, price: productPrice(activeProduct), status: "Processing", created: new Date(createdAt).toLocaleString(), createdAt, customer: user.username, playerDetails: checkoutFields, payment, transactionId, proof: proofData || proofName };
    setOrderHistory(previous => [newOrder, ...previous].slice(0, 1000));
    setOrderStatus(prev => ({ ...prev, [orderId]: "Processing" }));
    if (payment === "Wallet") setUser({ ...user, wallet: user.wallet - productPrice(activeProduct) });
    setActiveProduct(null);
  };

  const finishWalletDeposit = () => {
    if (!user || payment === "Wallet" || !walletTx || !walletProof || walletAmount < 100 || walletAmount > 10000) return;
    setWalletRequests(previous => [{ id: `WAL-${Date.now().toString().slice(-6)}`, username: user.username, amount: walletAmount, method: payment, transactionId: walletTx, proof: walletProof, proofData: walletProofData, status: "Processing", created: new Date().toLocaleString(), createdAt: Date.now() }, ...previous]);
    setWalletOpen(false); setWalletTx(""); setWalletProof(""); setWalletProofData("");
  };

  const login = () => {
    setAuthOpen(false);
    startLogin();
  };

  const updateWalletRequest = (id: string, status: OrderStatus, rejectionReason?: string) => {
    const request = walletRequests.find(item => item.id === id);
    if (!request) return;
    if (request.status !== "Completed" && status === "Completed") {
      setCustomerAccounts(previous => Object.fromEntries(Object.entries(previous).map(([key, account]) => account.username === request.username ? [key, { ...account, wallet: account.wallet + request.amount }] : [key, account])));
      if (user?.username === request.username) setUser(current => current ? { ...current, wallet: current.wallet + request.amount } : current);
      pushNotification(request.username, `${formatRs(request.amount)} wallet deposit approved. Your balance has been updated.`);
    }
    if (status === "Rejected") pushNotification(request.username, `Wallet deposit rejected${rejectionReason ? `: ${rejectionReason}` : "."}`);
    setWalletRequests(previous => previous.map(item => item.id === id ? { ...item, status, ...(rejectionReason ? { rejectionReason } : {}) } : item));
  };

  const updateOrderStatus = (orderId: string, status: OrderStatus, rejectionReason?: string) => {
    const order = orders.find(item => item.id === orderId);
    if (!order) return;
    setOrderHistory(orders.map(item => item.id === orderId ? { ...item, status, ...(rejectionReason ? { rejectionReason } : {}) } : item));
    setOrderStatus(previous => ({ ...previous, [orderId]: status }));
    if (status === "Completed") pushNotification(order.customer, `${order.product} completed successfully.`);
    if (status === "Rejected") pushNotification(order.customer, `${order.product} was rejected${rejectionReason ? `: ${rejectionReason}` : "."}`);
  };

  const saveAdminPassword = () => {
    const next = newAdminPassword.trim();
    if (!next) return;
    setAdminStoredPassword(next);
    try { localStorage.setItem("onpon-admin-password", next); } catch {}
    setNewAdminPassword("");
    setPasswordNotice("Password updated for this browser.");
  };

  const creditCustomerWallet = () => {
    const target = Object.values(customerAccounts).find(account => account.username.toLowerCase() === adminWalletUsername.trim().toLowerCase());
    if (!target || adminWalletAmount < 1) { setWalletAdminNotice("Customer username not found or amount is invalid."); return; }
    setCustomerAccounts(previous => ({ ...previous, [target.openId]: { ...target, wallet: target.wallet + adminWalletAmount } }));
    if (auth.user?.openId === target.openId) setUser(previous => previous ? { ...previous, wallet: previous.wallet + adminWalletAmount } : previous);
    pushNotification(target.username, `${formatRs(adminWalletAmount)} has been added to your wallet by admin.`);
    setWalletAdminNotice(`${formatRs(adminWalletAmount)} added to @${target.username}.`);
    setAdminWalletAmount(100);
  };

  const deleteOrder = (orderId: string) => {
    setOrderHistory(previous => previous.filter(order => order.id !== orderId));
    setOrderStatus(previous => { const next = { ...previous }; delete next[orderId]; return next; });
  };
  const deleteWalletRequest = (requestId: string) => setWalletRequests(previous => previous.filter(request => request.id !== requestId));

  const selectCategory = (category: Category) => { setActiveCategory(category); setMobileMenu(false); document.getElementById("catalog")?.scrollIntoView({ behavior: "smooth" }); };

  useEffect(() => {
    const timers = notifications.map(notification => window.setTimeout(() => setNotifications(previous => previous.filter(item => item.id !== notification.id)), Math.max(100, 3000 - (notification.createdAt ? Date.now() - notification.createdAt : 0))));
    return () => timers.forEach(timer => window.clearTimeout(timer));
  }, [notifications]);
  const visibleNotifications = user ? notifications.filter(notification => notification.username === user.username).slice(0, 4) : [];
  return <div className="site-shell">{visibleNotifications.length > 0 && <div className="notification-stack" aria-live="polite">{visibleNotifications.map(notification => <div className="customer-notification" key={notification.id}><CheckCircle2 size={16} /><span>{notification.message}</span><button onClick={() => setNotifications(previous => previous.filter(item => item.id !== notification.id))} aria-label="Dismiss notification"><X size={14} /></button></div>)}</div>}
    <header className="topbar">
      <div className="topbar-inner">
        <button className="brand" onClick={() => selectCategory("All")}><span className="brand-mark">o</span><span><strong>onpon</strong><small>TOP UP SHOP</small></span></button>
        <nav className={`main-nav ${mobileMenu ? "nav-open" : ""}`}><button onClick={() => selectCategory("All")}>Shop</button><button onClick={() => selectCategory("Free Fire")}>Free Fire</button><button onClick={() => selectCategory("PUBG UC")}>PUBG UC</button><button onClick={() => selectCategory("Mobile Legends")}>Mobile Legends</button></nav>
        <div className="top-actions"><button className="icon-button" onClick={toggleTheme} aria-label="Toggle dark mode">{theme === "dark" ? <Sun size={17} /> : <Moon size={17} />}</button><button className="cart-button" onClick={() => user ? setProfileOpen(true) : setAuthOpen(true)}><UserCircle2 size={17} /> <span>{user ? user.username : "Login"}</span></button><button className="mobile-menu-button icon-button" onClick={() => setMobileMenu(!mobileMenu)}><Menu size={18} /></button></div>
      </div>
    </header>

    <main>
      <section className="hero-section"><div className="hero-noise" /><div className="hero-copy"><div className="hero-kicker"><span className="live-dot" /> NEPAL'S PLAYER-FIRST TOP-UP SHOP</div><h1>Power up.<br /><span>Play louder.</span></h1><p>Diamonds, UC and passes for the games you never put down. Fast checkout, clear pricing, real support.</p><div className="hero-actions"><button className="primary-button" onClick={() => selectCategory("Free Fire")}>Start topping up <ArrowRight size={16} /></button><button className="ghost-button light" onClick={() => setWalletOpen(true)}><WalletCards size={16} /> Add to wallet</button></div><div className="hero-trust"><span><ShieldCheck size={15} /> Secure payments</span><span><Zap size={15} /> Quick delivery</span><span><ReceiptText size={15} /> Order tracking</span></div></div><div className="hero-art"><div className="hero-ring ring-one" /><div className="hero-ring ring-two" /><div className="hero-card"><div className="hero-card-top"><span>ONPON / 2026</span><span>01</span></div><div className="hero-diamond">◆</div><div className="hero-card-title">TOP UP<br /><em>YOUR GAME</em></div><div className="hero-card-bottom"><span>FF / PUBG / MLBB</span><span>READY</span></div></div></div></section>

      {noticeVisible && <div className="notice-strip"><div><span className="notice-label">NOTICE</span><span>Trusted, affordable & secure top-up for Nepali gamers.</span></div><button className="icon-button" onClick={() => setNoticeVisible(false)}><X size={17} /></button></div>}

      <section className="section-wrap category-section"><div className="section-heading"><div><p className="eyebrow">BROWSE THE STACK</p><h2>What are you topping up?</h2></div><button className="text-button" onClick={() => selectCategory("All")}>View all <ChevronRight size={15} /></button></div><div className="category-rail">{(Object.keys(categoryMeta) as Category[]).map(category => { const meta = categoryMeta[category]; const Icon = meta.icon; return <button key={category} className={`category-pill ${activeCategory === category ? "selected" : ""}`} onClick={() => selectCategory(category)}><span className="category-icon"><Icon size={18} /></span><span><strong>{meta.label}</strong><small>{meta.hint}</small></span><ChevronRight size={15} /></button>; })}</div></section>

      <section className="section-wrap catalog-section" id="catalog"><div className="section-heading"><div><p className="eyebrow">{activeCategory === "All" ? "TOP-UP CATALOG" : activeCategory.toUpperCase()}</p><h2>{activeCategory === "All" ? "Choose a game or service." : categoryMeta[activeCategory].label}</h2><p className="section-note">{activeCategory === "All" ? "Tap a catalog to see its packages and start your top-up." : "Choose a package, enter your player details, and pay your way."}</p></div>{activeCategory !== "All" && <div className="catalog-count">{displayedProducts.length} <span>packages</span></div>}</div>{activeCategory === "All" ? <div className="catalog-directory">{(Object.keys(categoryMeta).filter(category => category !== "All") as Exclude<Category, "All">[]).map(category => { const meta = categoryMeta[category]; const Icon = meta.icon; const count = allProducts.filter(product => product.category === category).length; return <button className={`directory-card directory-${category.toLowerCase().replace(/\s+/g, "-")}`} style={catalogImageOverrides[category] ? { backgroundImage: `linear-gradient(135deg, rgba(12,12,12,.32), rgba(12,12,12,.75)), url(${catalogImageOverrides[category]})` } : undefined} key={category} onClick={() => selectCategory(category)}><span className="directory-icon"><Icon size={22} /></span><span className="directory-copy"><strong>{meta.label}</strong><small>{meta.hint}</small><em>{count} packages</em></span><span className="directory-arrow"><ArrowRight size={17} /></span></button>; })}</div> : <div className="product-grid">{displayedProducts.map(product => <article className="product-card" key={product.id}><div className="product-art-wrap"><CatalogArt product={product} imageUrl={imageOverrides[product.id]} />{product.tag && <span className="product-tag">{product.tag}</span>}</div><div className="product-info"><div><h3>{product.name}</h3><p>{product.subtitle}</p></div><div className="product-buy"><strong>{formatRs(productPrice(product))}</strong><button className={`buy-button ${!productInStock(product) ? "out-of-stock-button" : ""}`} onClick={() => openCheckout(product)} disabled={!productInStock(product)}>{productInStock(product) ? <>Buy <ArrowRight size={14} /></> : "Out of stock"}</button></div></div></article>)}</div>}</section>

      <section className="feature-wrap"><div className="wallet-banner"><div className="wallet-icon"><WalletCards size={25} /></div><div><p className="eyebrow">ONPON WALLET</p><h2>Load once. Checkout faster.</h2><p>Keep your balance ready for every diamond drop. Deposit Rs 100 – Rs 10,000 using your preferred QR.</p></div><button className="light-button" onClick={() => user ? setWalletOpen(true) : setAuthOpen(true)}>Open wallet <ArrowRight size={15} /></button></div><div className="steps-grid"><div className="step-card"><span>01</span><Gamepad2 size={20} /><h3>Pick a package</h3><p>Choose the exact game credit or voucher you need.</p></div><div className="step-card"><span>02</span><UserRoundPen size={20} /><h3>Share player details</h3><p>UID, player ID, zone ID or delivery contact — only what matters.</p></div><div className="step-card"><span>03</span><CheckCircle2 size={20} /><h3>Pay & track</h3><p>Use QR or wallet, then follow your order from processing to done.</p></div></div></section>

      <section className="section-wrap reassurance"><div className="reassurance-copy"><p className="eyebrow">BUILT FOR BUSY PLAYERS</p><h2>No noise. No mystery fees.</h2><p>Everything is listed in Nepalese rupees, with the payment proof and order status visible in your profile.</p></div><div className="reassurance-list"><div><ShieldCheck size={19} /><span><strong>Proof-first payments</strong><small>Transaction ID + screenshot for every QR payment.</small></span></div><div><Clock3 size={19} /><span><strong>Order visibility</strong><small>See processing or completed orders anytime.</small></span></div><div><LockKeyhole size={19} /><span><strong>Account gated</strong><small>Only logged-in players can purchase or use wallet.</small></span></div></div></section>
    </main>

    <footer className="footer"><div className="footer-inner"><div><button className="brand footer-brand" onClick={() => selectCategory("All")}><span className="brand-mark">o</span><span><strong>onpon</strong><small>TOP UP SHOP</small></span></button><p>Your next win starts with a better top-up.</p></div><div className="footer-actions"><button onClick={() => user ? setProfileOpen(true) : setAuthOpen(true)}>{user ? "My profile" : "Login"}</button><button onClick={() => setAdminOpen(true)}>Admin dashboard</button><button onClick={toggleTheme}>{theme === "dark" ? "Light mode" : "Dark mode"}</button></div></div><div className="footer-bottom"><span>© 2026 onpon top up shop</span><span>Made for players in Nepal</span></div></footer><a className="whatsapp-float" href="https://wa.me/9779849854981?text=Hi%20onpon%20top%20up%20shop%2C%20I%20need%20help%20with%20an%20order." target="_blank" rel="noreferrer"><MessageCircle size={19} /><span>WhatsApp support</span></a>

    {authOpen && <Modal title="Log in to keep playing" eyebrow="PLAYER ACCESS" onClose={() => setAuthOpen(false)}><p className="modal-lead">Create your onpon profile with Google to buy packages, save orders, and use your wallet.</p><button className="google-button" onClick={login}><span className="google-g">G</span> Continue with Google</button><div className="oauth-note"><ShieldCheck size={17} /><div><strong>Real account login</strong><p>Continue opens the secure Manus account portal, where customers can use their connected Google account. No demo profile is created in the shop.</p></div></div><p className="small-note"><LockKeyhole size={13} /> Your OAuth name becomes your profile name; your editable username appears on wallet deposits in the admin panel.</p></Modal>}

    {activeProduct && <Modal title={`Checkout / ${activeProduct.name}`} eyebrow={activeProduct.category.toUpperCase()} onClose={() => setActiveProduct(null)} wide><div className="checkout-layout"><div className="checkout-product"><CatalogArt product={activeProduct} imageUrl={imageOverrides[activeProduct.id]} /><div className="checkout-summary"><span>{activeProduct.subtitle}</span><strong>{formatRs(productPrice(activeProduct))}</strong></div>{activeProduct.warning && <div className="warning-box"><span>!</span><p>{activeProduct.warning}</p></div>}</div><div className="checkout-form"><div className="form-section-title"><span>1</span><div><strong>Player details</strong><small>Only used to deliver your top-up.</small></div></div>{activeProduct.fields.map(field => <label key={field}>{field}<input value={checkoutFields[field] ?? ""} onChange={e => setCheckoutFields({ ...checkoutFields, [field]: e.target.value })} placeholder={`Enter ${field.toLowerCase()}`} /></label>)}<div className="form-section-title"><span>2</span><div><strong>Choose payment</strong><small>Your choice, your control.</small></div></div><div className="payment-options">{(["eSewa", "Khalti", "Mobile banking", "Wallet"] as PaymentMethod[]).map(method => <button key={method} className={`payment-option ${payment === method ? "selected" : ""}`} onClick={() => setPayment(method)}><span className={`payment-dot payment-${method.toLowerCase().replace(" ", "-")}`}>{method === "Wallet" ? "W" : method === "eSewa" ? "e" : method === "Khalti" ? "K" : "S"}</span><span>{method}<small>{method === "Wallet" ? `Balance ${formatRs(user?.wallet ?? 0)}` : "Pay with QR"}</small></span>{payment === method && <Check size={15} />}</button>)}</div>{payment !== "Wallet" ? <div className="payment-proof"><div className="qr-frame"><img src={qrCodes[payment]} alt={`${payment} payment QR`} /></div><div className="proof-copy"><strong>Scan with {payment}</strong><p>Pay exactly {formatRs(productPrice(activeProduct))}, then add the proof below.</p><label>Transaction ID<input value={transactionId} onChange={e => setTransactionId(e.target.value)} placeholder="e.g. 9811505419" /></label><label className="upload-field"><Upload size={15} />{proofName || "Upload payment screenshot"}<input type="file" accept="image/*" onChange={e => { const file = e.target.files?.[0]; if (file) { setProofName(file.name); readGalleryImage(file, setProofData); } }} /></label></div></div> : <div className="wallet-checkout"><WalletCards size={19} /><div><strong>Pay from onpon wallet</strong><p>Available balance: {formatRs(user?.wallet ?? 0)}. {user && user.wallet < productPrice(activeProduct) ? "Add money to wallet before checkout." : "Your order will be placed instantly."}</p></div></div>}<button className="primary-button full" onClick={finishCheckout}>{payment === "Wallet" ? "Pay from wallet" : "Submit payment proof"} <ArrowRight size={16} /></button><p className="small-note"><ShieldCheck size={13} /> Orders are reviewed and updated in your profile.</p></div></div></Modal>}

    {walletOpen && <Modal title="Add money to wallet" eyebrow="ONPON WALLET" onClose={() => setWalletOpen(false)}><p className="modal-lead">Deposit between Rs 100 and Rs 10,000. Your username will be attached to the wallet request for admin review.</p><div className="wallet-balance-large"><span>Current balance</span><strong>{formatRs(user?.wallet ?? 0)}</strong></div><label>Deposit amount<input type="number" min="100" max="10000" step="1" value={walletAmount} onChange={e => setWalletAmount(Number(e.target.value))} placeholder="Any amount from Rs 100 to Rs 10,000" /><small>Choose any whole-rupee amount between Rs 100 and Rs 10,000.</small></label><div className="payment-options compact">{(["eSewa", "Khalti", "Mobile banking"] as PaymentMethod[]).map(method => <button key={method} className={`payment-option ${payment === method ? "selected" : ""}`} onClick={() => setPayment(method)}><span className={`payment-dot payment-${method.toLowerCase().replace(" ", "-")}`}>{method === "eSewa" ? "e" : method === "Khalti" ? "K" : "S"}</span><span>{method}<small>Scan QR to deposit</small></span>{payment === method && <Check size={15} />}</button>)}</div><div className="wallet-qr"><img src={qrCodes[payment === "Wallet" ? "eSewa" : payment]} alt={`${payment} wallet deposit QR`} /><div><strong>Scan {payment}</strong><p>Use your banking app and keep the transaction receipt.</p></div></div><label>Transaction ID<input value={walletTx} onChange={e => setWalletTx(e.target.value)} placeholder="e.g. TXN-2026-001" /></label><label className="upload-field"><Upload size={15} />{walletProof || "Upload deposit screenshot"}<input type="file" accept="image/*" onChange={e => { const file = e.target.files?.[0]; if (file) { setWalletProof(file.name); readGalleryImage(file, setWalletProofData); } }} /></label><button className="primary-button full" onClick={finishWalletDeposit}>Submit wallet deposit <ArrowRight size={16} /></button></Modal>}

    {profileOpen && user && <Modal title={`Hey, ${user.name.split(" ")[0]}`} eyebrow="PLAYER PROFILE" onClose={() => setProfileOpen(false)}><div className="profile-head"><div className="profile-avatar">{user.name.charAt(0)}</div><div><strong>@{user.username}</strong><span>onpon player</span></div><button className="icon-button" onClick={() => { void auth.logout(); setUser(null); setProfileOpen(false); }}><LogOut size={16} /></button></div><div className="profile-tabs"><button className={profileTab === "profile" ? "active" : ""} onClick={() => setProfileTab("profile")}>Profile & wallet</button><button className={profileTab === "orders" ? "active" : ""} onClick={() => setProfileTab("orders")}>Order history</button></div>{profileTab === "profile" ? <><div className="wallet-balance-large"><span>Wallet balance</span><strong>{formatRs(user.wallet)}</strong><button className="text-button" onClick={() => { setProfileOpen(false); setWalletOpen(true); }}>Add money <Plus size={14} /></button></div><label>Full name<input value={user.name} onChange={e => setUser({ ...user, name: e.target.value })} /></label><label>Username<input value={usernameDraft} onChange={e => setUsernameDraft(e.target.value)} /></label><button className="primary-button full" onClick={() => setUser({ ...user, username: usernameDraft.trim().replace(/\s+/g, "_").toLowerCase() || user.username })}><Save size={16} /> Save profile</button></> : <><div className="history-filter"><strong>Order history</strong><div>{([["1d","1 day"],["7d","7 days"],["1m","1 month"],["1y","1 year"]] as const).map(([value, label]) => <button className={customerOrderRange === value ? "active" : ""} key={value} onClick={() => setCustomerOrderRange(value)}>{label}</button>)}</div></div><div className="orders-list">{customerOrders.length ? customerOrders.map(order => <div className="order-row" key={order.id}><div><strong>{order.product}</strong><small>{order.id} · {order.created}</small></div><span className={`status-badge ${order.status.toLowerCase()}`}><span />{order.status}</span><b>{formatRs(order.price)}</b>{order.status === "Completed" && <button className="icon-button history-delete" onClick={() => deleteOrder(order.id)} aria-label="Delete completed order"><Trash2 size={14} /></button>}</div>) : null}{customerWalletHistory.map(request => <div className="order-row wallet-history-row" key={request.id}><div><strong>Wallet deposit</strong><small>{request.id} · {request.created} · {request.method}</small></div><span className={`status-badge ${request.status.toLowerCase()}`}><span />{request.status}</span><b>{formatRs(request.amount)}</b></div>)}{customerOrders.length || customerWalletHistory.length ? null : <div className="empty-state"><ReceiptText size={20} /><strong>No orders yet</strong><span>Your purchases will show up here.</span></div>}</div></>}</Modal>}

    {adminOpen && <Modal title={adminAuthed ? "Admin control room" : "Admin access"} eyebrow="ONPON ADMIN" onClose={() => { setAdminOpen(false); setAdminAuthed(false); setAdminPassword(""); }} wide>{!adminAuthed ? <><div className="admin-lock"><div><LockKeyhole size={22} /></div><strong>Only the shop owner can enter.</strong><span>Manage pricing, catalog imagery, orders and wallet deposits.</span></div><label>Admin password<input type="password" value={adminPassword} onChange={e => setAdminPassword(e.target.value)} placeholder="Enter admin password" /></label><button className="primary-button full" onClick={() => adminPassword === adminStoredPassword ? setAdminAuthed(true) : setAdminPassword("")}>Unlock admin panel <ArrowRight size={16} /></button><p className="small-note">Password protected shop operations.</p></> : <div className="admin-panel"><div className="admin-tabs">{([["overview", BarChart3, "Dashboard"], ["orders", ReceiptText, "Orders"], ["catalog", Tags, "Catalog"]] as const).map(([tab, Icon, label]) => <button className={adminTab === tab ? "active" : ""} key={tab} onClick={() => setAdminTab(tab)}><Icon size={16} />{label}</button>)}</div>{adminTab === "overview" && <><div className="metric-grid"><div><span>Today</span><strong>{orders.length}</strong><small>orders</small></div><div><span>This week</span><strong>{orders.length + 12}</strong><small>orders</small></div><div><span>This month</span><strong>{orders.length + 48}</strong><small>orders</small></div><div><span>Wallet queue</span><strong>{walletRequests.filter(request => request.status === "Processing").length}</strong><small>to review</small></div></div><div className="admin-callout"><BarChart3 size={19} /><div><strong>Orders are moving.</strong><p>Track daily, weekly and monthly demand, then keep your best packages easy to find.</p></div></div><div className="admin-password-box"><div><strong>Admin password</strong><small>Change the password used to unlock this panel.</small></div><div className="admin-password-row"><input type="password" value={newAdminPassword} onChange={e => setNewAdminPassword(e.target.value)} placeholder="New password" /><button className="primary-button" onClick={saveAdminPassword}><Save size={15} /> Change</button></div>{passwordNotice && <p className="password-notice"><CheckCircle2 size={14} />{passwordNotice}</p>}</div><div className="admin-password-box admin-wallet-credit"><div><strong>Add money to customer wallet</strong><small>Use a saved customer username from a real Google account.</small></div><div className="admin-password-row"><input value={adminWalletUsername} onChange={e => setAdminWalletUsername(e.target.value)} placeholder="Customer username" /><input type="number" min="1" value={adminWalletAmount} onChange={e => setAdminWalletAmount(Number(e.target.value))} placeholder="Amount" /><button className="primary-button" onClick={creditCustomerWallet}><CircleDollarSign size={15} /> Add</button></div>{walletAdminNotice && <p className="password-notice"><CheckCircle2 size={14} />{walletAdminNotice}</p>}</div></>}{adminTab === "orders" && <div className="admin-table"><div className="history-filter admin-history-filter"><strong>Customer orders</strong><div>{([["1d","1 day"],["7d","7 days"],["1m","1 month"],["1y","1 year"]] as const).map(([value, label]) => <button className={adminOrderRange === value ? "active" : ""} key={value} onClick={() => setAdminOrderRange(value)}>{label}</button>)}</div></div>{adminOrders.map(order => <div className="admin-order" key={order.id}><div><strong>{order.product}</strong><small>{order.id} · @{order.customer} · {order.created}</small><small>{Object.entries(order.playerDetails ?? {}).map(([key, value]) => `${key}: ${value}`).join(" · ") || "No player details"}{order.payment ? ` · ${order.payment}` : ""}{order.transactionId ? ` · Txn ${order.transactionId}` : ""}</small>{order.proof?.startsWith("data:") && <><a className="proof-link" href={order.proof} target="_blank" rel="noreferrer">View payment screenshot</a><img className="proof-preview" src={order.proof} alt="Customer payment proof" /></>}</div><b>{formatRs(order.price)}</b><select value={order.status} onChange={e => { const next = e.target.value as OrderStatus; const productId = order.id; if (next === "Rejected") { const reason = window.prompt("Why are you rejecting this order?", order.rejectionReason || "")?.trim(); if (!reason) return; updateOrderStatus(productId, next, reason); } else updateOrderStatus(productId, next); }}><option>Processing</option><option>Completed</option><option>Rejected</option></select>{order.rejectionReason && <small className="rejection-reason">Reason: {order.rejectionReason}</small>}<button className="icon-button history-delete" onClick={() => deleteOrder(order.id)} aria-label="Delete order"><Trash2 size={14} /></button></div>)}{adminWalletRequests.map(request => <div className="admin-order wallet-admin-order" key={request.id}><div><strong>Wallet deposit · {request.username}</strong><small>{request.id} · {request.method} · Txn {request.transactionId} · {request.created}</small>{request.proofData ? <><a className="proof-link" href={request.proofData} target="_blank" rel="noreferrer">View uploaded payment screenshot</a><img className="proof-preview" src={request.proofData} alt="Wallet payment proof" /></> : <small>Screenshot: {request.proof || "Not provided"}</small>}{request.rejectionReason && <small className="rejection-reason">Reason: {request.rejectionReason}</small>}</div><b>{formatRs(request.amount)}</b><div className="request-actions"><span className={`status-badge ${request.status.toLowerCase()}`}><span />{request.status}</span>{request.status === "Processing" && <><button className="approve-button" onClick={() => updateWalletRequest(request.id, "Completed")}>Approve</button><button className="reject-button" onClick={() => { const reason = window.prompt("Why are you rejecting this wallet deposit?", request.rejectionReason || "")?.trim(); if (reason) updateWalletRequest(request.id, "Rejected", reason); }}>Reject</button></>}</div><button className="icon-button history-delete" onClick={() => deleteWalletRequest(request.id)} aria-label="Delete wallet request"><Trash2 size={14} /></button></div>)}{!adminOrders.length && !adminWalletRequests.length && <div className="empty-state"><ReceiptText size={20} /><strong>No customer orders yet</strong><span>New purchases and wallet deposits will appear here with username and status.</span></div>}</div>}{adminTab === "catalog" && <div className="admin-catalog"><div className="admin-create-product"><div><strong>Add a new product</strong><small>Create another package inside any catalog. Price, player fields, and gallery image are saved across devices.</small></div><div className="create-product-grid"><label>Catalog<select value={newProduct.category} onChange={e => setNewProduct({ ...newProduct, category: e.target.value as Exclude<Category, "All"> })}>{(["Free Fire", "PUBG UC", "Mobile Legends", "UniPin", "Level Up Pass"] as Exclude<Category, "All">[]).map(category => <option key={category}>{category}</option>)}</select></label><label>Product name<input value={newProduct.name} onChange={e => setNewProduct({ ...newProduct, name: e.target.value })} placeholder="e.g. 100 Diamonds" /></label><label>Subtitle<input value={newProduct.subtitle} onChange={e => setNewProduct({ ...newProduct, subtitle: e.target.value })} placeholder="Short description" /></label><label>Price<input type="number" min="0" value={newProduct.price} onChange={e => setNewProduct({ ...newProduct, price: Number(e.target.value) })} /></label><label>Player fields<small>Separate fields with commas</small><input value={newProduct.fields} onChange={e => setNewProduct({ ...newProduct, fields: e.target.value })} placeholder="Game UID, Game name" /></label><label className="gallery-picker"><span>Product image</span><span className="gallery-button"><ImagePlus size={14} />{newProductImage ? "Image selected" : "Choose from gallery"}<input type="file" accept="image/*" onChange={e => { const file = e.target.files?.[0]; if (file) readGalleryImage(file, setNewProductImage); e.currentTarget.value = ""; }} /></span></label></div><button className="primary-button" onClick={() => { if (!newProduct.name.trim() || newProduct.price < 0) return; const created: Product = { id: `custom-${Date.now()}`, category: newProduct.category, name: newProduct.name.trim(), subtitle: newProduct.subtitle.trim() || "New top-up package", price: newProduct.price, fields: newProduct.fields.split(",").map(field => field.trim()).filter(Boolean), accent: "red", art: newProduct.name.trim().slice(0, 5).toUpperCase() }; setCustomProducts(previous => [...previous, created]); if (newProductImage) setImageOverrides(previous => ({ ...previous, [created.id]: newProductImage })); setNewProduct({ category: newProduct.category, name: "", subtitle: "", price: 100, fields: "Game UID, Game name" }); setNewProductImage(""); }}>Add product <Plus size={15} /></button></div><div className="catalog-cover-settings"><div><strong>Catalog cover images</strong><small>Choose an image from your phone gallery. It is saved in this browser and remains after refresh.</small></div>{(["Free Fire", "PUBG UC", "Mobile Legends", "UniPin", "Level Up Pass"] as Exclude<Category, "All">[]).map(category => <label className="gallery-picker" key={category}><span>{category}</span><span className="gallery-button"><ImagePlus size={14} />{catalogImageOverrides[category] ? "Change from gallery" : "Choose from gallery"}<input type="file" accept="image/*" onChange={e => { const file = e.target.files?.[0]; if (file) readGalleryImage(file, dataUrl => setCatalogImageOverrides(previous => ({ ...previous, [category]: dataUrl }))); e.currentTarget.value = ""; }} /></span></label>)}</div>{allProducts.map(product => <div className="admin-product" key={product.id}><CatalogArt product={product} imageUrl={imageOverrides[product.id]} /><div><strong>{product.name}</strong><small>{product.category}</small><label>Price<input type="number" value={priceOverrides[product.id] ?? product.price} onChange={e => setPriceOverrides({ ...priceOverrides, [product.id]: Number(e.target.value) })} /></label><label className="stock-toggle"><input type="checkbox" checked={productInStock(product)} onChange={e => setStockOverrides(previous => ({ ...previous, [product.id]: e.target.checked }))} /><span>{productInStock(product) ? "In stock" : "Out of stock"}</span></label><label className="gallery-picker"><span>Package reference image</span><span className="gallery-button"><ImagePlus size={14} />{imageOverrides[product.id] ? "Change from gallery" : "Choose from gallery"}<input type="file" accept="image/*" onChange={e => { const file = e.target.files?.[0]; if (file) readGalleryImage(file, dataUrl => setImageOverrides(previous => ({ ...previous, [product.id]: dataUrl }))); e.currentTarget.value = ""; }} /></span></label></div></div>)}</div>}</div>}</Modal>}
  </div>;
}
